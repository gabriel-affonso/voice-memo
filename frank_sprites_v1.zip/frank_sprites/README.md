# Frank sprites — ESP32-S3-Touch-ePaper-1.54

Pacote inicial de sprites monocromáticos para a tela e-paper 200×200 do Frank.

## Estados

- `dead`: olhos X X — usar antes de desligar.
- `closed`: olhos fechados.
- `half_open`: um olho abrindo.
- `awake`: estado idle/normal.
- `blink`: piscada.
- `happy`: confirmação/sucesso.
- `recording`: gravação de áudio.
- `error`: erro/falha.

## Arquivos

- `frank_<estado>_200x200.png`: sprite completo.
- `face_overlays_96x52/`: apenas a região dos olhos/boca para refresh parcial.
- `frank_sprite_sheet_800x400.png`: referência visual.
- `frank_sprites.h`: arrays 1-bit MSB-first em `PROGMEM`.

Cada sprite completo ocupa 5000 bytes.
Cada overlay 96×52 ocupa 624 bytes.

## Exemplo com API estilo Adafruit_GFX

```cpp
#include "frank_sprites.h"

// display.drawBitmap(x, y, bitmap, w, h, BLACK);

void showFrankFull(FrankState state) {
  display.fillScreen(WHITE);
  display.drawBitmap(
    0, 0,
    frankFullSprite(state),
    FRANK_W, FRANK_H,
    BLACK
  );
  // use aqui o método de refresh completo da sua biblioteca
}

void showFrankFace(FrankState state) {
  display.fillRect(
    FRANK_FACE_X, FRANK_FACE_Y,
    FRANK_FACE_W, FRANK_FACE_H,
    WHITE
  );

  display.drawBitmap(
    FRANK_FACE_X, FRANK_FACE_Y,
    frankFaceSprite(state),
    FRANK_FACE_W, FRANK_FACE_H,
    BLACK
  );

  // use aqui o método de refresh parcial da biblioteca Waveshare/GxEPD2
}
```

## Sequência sugerida de boot

`DEAD -> CLOSED -> HALF_OPEN -> AWAKE -> BLINK -> AWAKE`

A animação funciona melhor com ~200–350 ms entre os frames, respeitando o tempo de refresh parcial do painel.
